<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Porfolio Roger</title>
    
    <link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'template_url' ); ?>" />

    <link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'template_url' ); ?>/css/style.css" />
    
</head>




<body>



    <div class="titulo">
        <h1>PORTFOLIO</h1>
    </div>

    <a href="yo.html" class="roger">
        <h2>Roger Belles</h2>  
    </a>

    <div class="avioneta">
        <img src="img/7817.png" alt="">
    </div>
    

    <div class="contenedor">
    <ul>
            <a href="mp08_UF1_01_bellesr/mp08_UF1_bellesr.html" class="cloud" id="c1">
                <li>
                    <h3>01</h3>
                </li>
            </a>


            <a href="mp08_UF1_02_horari_bellesr/index.html" class="cloud" id="c2">
                <li>
                    <h3>02</h3>
                </li>
            </a>


            <a href="mp08_UF1_03_feedly_bellesr/index.html" class="cloud" id="c3">
                <li>
                    <h3>03</h3>
                </li>
            </a>


            <a href="mp08_UF1_04_bellesr/index.html" class="cloud" id="c4">
                <li>
                    <h3>04</h3>
                </li>
            </a>


            <a href="mp08_UF1_05_escacs_bellesr/index.html" class="cloud" id="c5">
                <li>
                    <h3>05</h3>
                </li>
            </a>


            <a href="mp08_UF1_06_absolute_bellesr/index.html" class="cloud" id="c6">
                <li>
                    <h3>06</h3>
                </li>
            </a>


            <a href="mp08_UF1_07_floreta_bellesr/index.html" class="cloud" id="c7">
                <li>
                    <h3>07</h3>
                </li>
            </a>


            <a href="mp08_UF1_08_cara_bellesr/index.html" class="cloud" id="c8">
                <li>
                    <h3>08</h3>
                </li>
            </a>


            <a href="mp08_UF1_09_photoshop/index.html" class="cloud" id="c9">
                <li>
                    <h3>09</h3>
                </li>
            </a>


            <a href="mp08_UF1_10_pelys_bellesr/index.html" class="cloud" id="c10">
                <li>
                    <h3>10</h3>
                </li>
            </a>


            


            
    </ul>
    </div>
    
    
    
    
    
    
    
    
    

</body>



</html>